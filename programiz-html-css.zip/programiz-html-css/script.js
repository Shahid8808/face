// script.js

const video = document.getElementById('video');

navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
  video.srcObject = stream;
});
// script.js (continued)

const modelUrl = 'https://storage.googleapis.com/tfjs-models/tfjs/mobilenet_v1_1.0_224/model.json';

let model;

async function loadModel() {
  model = await tf.loadLayersModel(modelUrl);
}

loadModel();

async function detectEyes() {
  // Convert the video frame to a tensor
  const tensor = tf.browser.fromPixels(video);

  // Resize the tensor to the required input size for MobileNet
  const resized = tf.image.resizeBilinear(tensor, [224, 224]);

  // Normalize the pixel values between -1 and 1
  const normalized = resized.div(127).sub(1);

  // Get the prediction for the normalized tensor
  const prediction = model.predict(normalized);

  // Get the top 5 predictions
  const top5 = prediction.topk(5).dataSync();

  // Check if 'Eye' is in the top 5 predictions
  if (top5.indexOf('Eye') > -1) {
    console.log('Eye detected!');
  }

  // Dispose the tensors to release the memory
  tensor.dispose();
  resized.dispose();
  normalized.dispose();
}

setInterval(detectEyes, 1000);
